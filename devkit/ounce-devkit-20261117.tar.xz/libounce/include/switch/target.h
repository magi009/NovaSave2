/**
 * @file target.h
 * @brief The platform that these headers are installed for: Switch 2.
 * @note Installed by make install-switch2: a program that includes these headers
 * is built for Switch 2 whatever its compiler flags.
 */
#pragma once

#ifndef __SWITCH2__
#define __SWITCH2__ 1
#endif
